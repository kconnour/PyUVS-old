"""
Docstring
=========
"""

import matplotlib.pyplot as plt

fig, ax = plt.subplots()
plt.show()
